from flask import Flask, render_template
from uuid import uuid4

from lib.auth import Auth
from lib.other import Other

from bson.objectid import ObjectId
import pymongo
from datetime import datetime

from werkzeug.security import generate_password_hash, check_password_hash
import logging

from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask import Flask, request, render_template, jsonify, redirect, url_for, flash, session

app = Flask(__name__)
app.config['SECRET_KEY'] = '187da830a1304a91b6dfec86b3abe1a0!'

admin = "6367fc50af4e4c7b4ba9af22"

# Подключение к локальной базе данных
connect = pymongo.MongoClient(
    f'mongodb://localhost:27017/')

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'main_page'

# Удаленная база данных
db = connect["database"]

db_users = db["users"]
db_ideas = db["ideas"]
db_category = db["category"]

auth = Auth(db_users=db_users)
other = Other(db_category=db_category, db_ideas=db_ideas)

class User_object_id(UserMixin):
    def __init__(self, user_json):
        self.user_json = user_json

    def get_id(self):
        object_id = self.user_json.get('_id')
        return str(object_id)


@login_manager.user_loader
def load_user(user_id):
    user_json = db_users.find_one({'_id': ObjectId(user_id)})
    return User_object_id(user_json)

def admin_required(func):
    """
    Декаратор для проверки сессии на наличие _user_id администратора.
    :return Выполняем функцию иначе перенаправляем на страницу ошибки.
    """
    def wrapper():
        if session and '_user_id' in session:
            if session['_user_id'] == admin:
                return func()
            else:
                return "Access is denied. <a href='https://www.cloudflare.com/'>Protected by cloudflare</a>"
        return "Access is denied. <a href='https://www.cloudflare.com/'>Protected by cloudflare</a>"
    wrapper.__name__ = func.__name__
    return wrapper


@app.route('/')
def index():
    # Авторизация пользователей
    return render_template('auth-login.html')

@app.route('/user/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth_login'))

@app.route('/auth-login', methods=['GET', 'POST'])
def auth_login():
    # Авторизация пользователей
    
    if request.method == "POST":

        user = auth.is_user(request.form["email"])

        if not user:
            flash("Такого пользователя не существует")
            return redirect(url_for('auth_login')) 

        if not check_password_hash(user['password'], request.form["password"]):
            flash("Не верный пароль")
            return redirect(url_for('auth_login')) 

        loginuser = load_user(user['_id'])
        login_user(loginuser, remember=True)
        
        if session["_user_id"] == admin:
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
        
    return render_template('auth-login.html', title="Авторизация")

@app.route('/auth-register', methods=['GET', 'POST'])
def auth_register():
    # Регистрация пользователей
    
    if request.method == "POST":

        username = request.form["username"]
        email = request.form["email"]
        
        password = request.form["password"]
        confirmation = request.form["confirmation"]
        
        if confirmation != password:
            flash("Пароли не совпадают")
            return redirect(url_for('auth_register')) 
        
        
        password = generate_password_hash(password,
                                          method='sha256')

        dt = datetime.now()
        timestamp = datetime.timestamp(dt)

        new_user = auth.reg_user(
            username, email, password, timestamp
        )

        if not new_user:
            flash("Ошибка регистрации аккаунта")
            return redirect(url_for('auth_register'))

        # Успешная регистрация
        flash("Успешная регистрация. Авторизуйтесь!")
        return redirect(url_for('auth_login'))

    if session and session["_user_id"] == admin:
        return redirect(url_for('admin_dashboard'))
    elif session and session["_user_id"] != admin:
        return redirect(url_for('user_dashboard'))
    
    return render_template('auth-register.html', title="Регистрация")


@app.route('/admin-dashboard', methods=['GET', 'POST'])
@admin_required
def admin_dashboard():
    
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})
    
    return render_template(
        '/admin/admin-dashboard.html', title="Админ панель", user_info=user_info
    )

@app.route('/admin/all-project', methods=['GET'])
@admin_required
def all_project():
    
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})

    is_ideas = db_ideas.find_one({"status": True, "verif": True})
    ideas = db_ideas.find({"status": True, "verif": True})
    
    return render_template(
        '/admin/all-project.html', title="Все проекты", user_info=user_info,
        is_ideas=is_ideas, ideas=ideas, 
    )
    
    
@app.route('/admin/category', methods=['GET'])
@admin_required
def admin_category():
    
    is_category = db_category.find_one({})
    category = db_category.find({})
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})
    
    return render_template(
        '/admin/category.html', title="Категории", user_info=user_info,
        is_category=is_category, category=category
    )
   

@app.route('/admin/reg-category', methods=['POST'])
@admin_required
def reg_category():
    name_category = request.form["name_category"]
    
    if not other.reg_category(name_category):
        flash("Ошибка создания категории")
        
    flash("Категория создана успешно")
    return redirect(url_for('admin_category'))


@app.route('/admin/verif', methods=['GET'])
@admin_required
def verif_admin():
    
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})
    
    is_ideas = db_ideas.find_one({"send-verif": True, "verif": False})
    ideas = db_ideas.find({"send-verif": True, "verif": False})
    
    return render_template(
        '/admin/verif.html', title="Проекты", user_info=user_info,
        is_ideas=is_ideas, ideas=ideas
    )
    
@app.route('/admin/users', methods=['GET'])
@admin_required
def users():
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})
    
    users = db_users.find({})
    
    return render_template(
        '/admin/users.html', title="Пользователи", user_info=user_info,
        users=users
    )
    
    
@app.route('/admin/delete-category', methods=['POST'])
@admin_required
def delete_category():
    
    id = request.form["id"]
    
    try:
        db_category.delete_one({"_id": ObjectId(id)})
    except Exception as e:
        flash("Ошибка удаления категории")
        return redirect(url_for('admin_category'))
    
    flash("Категория успешно удалена")
    return redirect(url_for('admin_category'))
    
@app.route('/admin/delete-user', methods=['POST'])
@admin_required
def delete_user():
    
    id = request.form["id"]
    
    try:
        db_users.delete_one({"_id": ObjectId(id)})
    except Exception as e:
        flash("Ошибка удаления пользователя")
        return redirect(url_for('admin_category'))
    
    flash("Пользователь успешно удален")
    return redirect(url_for('admin_category'))

@app.route('/user/delete-idea', methods=['POST'])
@login_required
def delete_idea():
    
    id = request.form["id"]
    
    try:
        db_ideas.delete_one({"_id": ObjectId(id)})
    except Exception as e:
        flash("Ошибка удаления идеи")
        return redirect(url_for('my_ideas'))
    
    flash("Идея успешно удалена")
    return redirect(url_for('my_ideas'))

@app.route('/user/all-project', methods=['GET'])
@login_required
def all_project_user():
    
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})

    is_ideas = db_ideas.find_one({"status": True, "verif": True})
    ideas = db_ideas.find({"status": True, "verif": True})
    
    return render_template(
        '/user/all-project.html', title="Все проекты", user_info=user_info,
        is_ideas=is_ideas, ideas=ideas, 
    )

@app.route('/user/send-verif', methods=['POST'])
@login_required
def send_verif():
    
    id = request.form["id"]
    
    try:
        db_ideas.update_one({'_id': ObjectId(id)}, {"$set": {
                                    "send_verif": True}}, upsert=True)
        
    except Exception as e:
        flash("Ошибка отправки идеи на модерацию")
        return redirect(url_for('my_ideas'))
    
    flash("Идея успешно отправлена на модерацию")
    return redirect(url_for('my_ideas'))


@app.route('/admin/delete-idea', methods=['POST'])
@admin_required
def delete_idea_admin():
    
    id = request.form["id"]
    
    try:
        db_ideas.delete_one({"_id": ObjectId(id)})
    except Exception as e:
        flash("Ошибка удаления идеи")
        return redirect(url_for('verif'))
    
    flash("Идея успешно удалена")
    return redirect(url_for('verif'))


@app.route('/admin/verif-true', methods=['POST'])
@admin_required
def verif_true():
    
    id = request.form["id"]
    
    try:
        db_ideas.update_one({'_id': ObjectId(id)}, {"$set": {
                                    "verif": True,
                                    "status": True}}, upsert=True)
        
    except Exception as e:
        flash("Ошибка подтверждения идеи")
        return redirect(url_for('admin_dashboard'))
    
    flash("Идея успешно подтверждена")
    return redirect(url_for('admin_dashboard'))

@app.route('/user-dashboard', methods=['GET', 'POST'])
@login_required
def user_dashboard():
    
    if session and session["_user_id"] == admin:
        return redirect(url_for('admin_dashboard'))
    
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})
        
    return render_template(
        '/user/user-dashboard.html', title="Личный кабинет", user_info=user_info
    )

@app.route('/user/my-ideas', methods=['GET', 'POST'])
@login_required
def my_ideas():
    user_id = session["_user_id"]
    user_info = db_users.find_one({"_id": ObjectId(user_id)})
        
    is_idea = db_ideas.find_one({"user_id": user_id})
    ideas = db_ideas.find({"user_id": user_id})
        
    category = db_category.find({})
    
    return render_template(
        '/user/my-ideas.html', title="Мои идеи", user_info=user_info,
        is_idea=is_idea, ideas=ideas, category=category
    )

@app.route('/user/reg-idea', methods=['POST'])
@login_required
def reg_idea():
    
    user_id = session["_user_id"]
    
    name_project = request.form["name_project"]
    name_category = request.form["name_category"]
    description = request.form["description"]
    
    new_idea = other.reg_idea(
        name_project, name_category, description, user_id
    )
    
    if not new_idea:
        print("!")
        flash("Ошибка добавления идеи")
        return redirect(url_for('my_ideas'))
        
    flash("Новая идея добавлена успешно")
    return redirect(url_for('my_ideas'))
    

app.run(debug=True, port=5001)