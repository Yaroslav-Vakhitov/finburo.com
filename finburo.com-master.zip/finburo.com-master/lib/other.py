class Other():
    
    def __init__(self, db_category, db_ideas):
        self._db_category = db_category
        self._db_ideas = db_ideas
        
    def reg_category(self, name_category):
        new_category = dict(name_category=name_category)
        try:
            self._db_category.insert_one(new_category)
        except Exception as e:
            return False
        return True
    
    def reg_idea(self, name_project, name_category, description, user_id):
        
        new_idea = dict(
            name_project=name_project,
            name_category=name_category,
            description=description,
            user_id=user_id,
            likes=0,
            block=False,
            status=False,
            send_verif=False,
            verif=False,
            comments=dict(
                user_id=None,
                comment=None
            )
        )
        
        try:
            self._db_ideas.insert_one(new_idea)
        except Exception as e:
            print(e)
            return False
        return True
        
        