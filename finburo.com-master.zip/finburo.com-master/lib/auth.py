from bson.objectid import ObjectId

class Auth():
    
    def __init__(self, db_users):
        self._db_users = db_users
                
    
    def reg_user(self, username: str, email: str, password: str, timestamp: int):
        """Регистрация пользователя
        
        Returns:
            _type_: bool 
        """
        new_user = dict(
            username=username, 
            email=email, 
            password=password, 
            timestamp=timestamp,
            work_status = 0, skills = dict(
                skill_id = None,
                skill_descr = None
            ),
            description = None, 
            command_id = None,
            skill_level = None,
            role="user"
        )
        
        try:
            self._db_users.insert_one(new_user)
        except Exception as e:
            return False
        return True
    
    
    def auth_user(self):
        pass
    
    
    def is_user(self, email):
        """Проверка на существование пользователя
        
        Returns:
            _type_: bool
        """
        user = self._db_users.find_one({"email": email})
        if not user:
            return False
        return user